#!/bin/bash

lockoutconfig() {
set -e
PAM_CONFIG_DIR="/usr/share/pam-configs"
COMMON_AUTH="/etc/pam.d/common-auth"
BACKUP="/etc/pam.d/common-auth.bak"
# Notify on account lockout
cat <<EOF | sudo tee "$PAM_CONFIG_DIR/faillock_notify" > /dev/null
Name: Notify on account lockout
Default: yes
Priority: 900
Auth-Type: Primary
Auth:
    pam_faillock.so even_deny_root audit silent deny=3 unlock_time=900
EOF
# Reset lockout on success
cat <<EOF | sudo tee "$PAM_CONFIG_DIR/faillock_reset" > /dev/null
Name: Reset lockout on success
Default: yes
Priority: 901
Auth-Type: Primary
Auth:
    pam_faillock.so authsucc audit deny=3 unlock_time=900
EOF
# Lockout on failed logins
cat <<EOF | sudo tee "$PAM_CONFIG_DIR/faillock" > /dev/null
Name: Lockout on failed logins
Default: yes
Priority: 902
Auth-Type: Primary
Auth:
    pam_faillock.so preauth audit silent deny=3 unlock_time=900
EOF

sudo cp "$COMMON_AUTH" "$BACKUP"
echo "Backup of common-auth saved to $BACKUP"
if ! grep -q "pam_faillock.so preauth" "$COMMON_AUTH"; then
    sudo sed -i '1i auth required pam_faillock.so preauth' "$COMMON_AUTH"
fi
if ! grep -q "pam_faillock.so authfail" "$COMMON_AUTH"; then
    sudo sed -i '2i auth [default=die] pam_faillock.so authfail' "$COMMON_AUTH"
fi
if ! grep -q "pam_faillock.so authsucc" "$COMMON_AUTH"; then
    sudo sed -i '3i auth sufficient pam_faillock.so authsucc' "$COMMON_AUTH"
fi
echo 'PAM lockout policies appended (hopefully) safely to common-auth.'
}

echo "Configuring pam configuration files this way will break ALL forms of password authentication; only use this script when you are done everything else on the image."
echo -e "Continue? (y/n): "
read ANSWER
[[ "$ANSWER" = "y" ]] && lockoutconfig
